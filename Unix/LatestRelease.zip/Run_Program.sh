echo Vulcan: A Nion Project.
echo Platform: Unix
java Launcher
